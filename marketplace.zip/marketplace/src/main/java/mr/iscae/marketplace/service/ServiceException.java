package mr.iscae.marketplace.service;

/**
 * Exception métier pour les services
 */
public class ServiceException extends Exception {

    private ErrorType errorType;

    public enum ErrorType {
        VALIDATION_ERROR,
        NOT_FOUND,
        UNAUTHORIZED,
        DUPLICATE_ENTRY,
        DATABASE_ERROR,
        IO_ERROR,
        AUTHENTICATION_ERROR,
        BUSINESS_ERROR
    }

    public ServiceException(String message, ErrorType errorType) {
        super(message);
        this.errorType = errorType;
    }

    public ServiceException(String message, ErrorType errorType, Throwable cause) {
        super(message, cause);
        this.errorType = errorType;
    }

    public ErrorType getErrorType() {
        return errorType;
    }

    public void setErrorType(ErrorType errorType) {
        this.errorType = errorType;
    }
}
package mr.iscae.marketplace.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import mr.iscae.marketplace.dao.AdminDAO;
import mr.iscae.marketplace.model.Admin;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private AdminDAO adminDAO;

    @Override
    public void init() throws ServletException {
        adminDAO = new AdminDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validation des champs
        if (email == null || email.trim().isEmpty() 
                || password == null || password.trim().isEmpty()) {
            
            HttpSession session = request.getSession();
            session.setAttribute("errorMessage", "Veuillez remplir tous les champs");
            response.sendRedirect("adminLogin.jsp");
            return;
        }	

        email = email.trim();
        password = password.trim();

        // Authentification de l'admin
        Admin admin = adminDAO.authenticate(email, password);

        if (admin != null) {
            // ✅ Connexion réussie
            HttpSession session = request.getSession();
            session.setAttribute("admin", admin);
            session.setAttribute("adminId", admin.getId());
            session.setAttribute("adminEmail", admin.getEmail());
            session.setAttribute("isAdmin", true);
            
            // Sécurité session
            session.setAttribute("csrfToken", java.util.UUID.randomUUID().toString());
            session.setAttribute("lastActivity", System.currentTimeMillis());
            session.setMaxInactiveInterval(60 * 60); // 1 heure pour admin

            session.setAttribute("successMessage", "Connexion admin réussie !");

            // Redirection vers le panneau d'administration
            response.sendRedirect(request.getContextPath() + "/AdminAnnonceServlet");
            
        } else {
            // ❌ Échec de connexion
            HttpSession session = request.getSession();
            session.setAttribute("errorMessage", "Email ou mot de passe incorrect");
            response.sendRedirect("adminLogin.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // Si déjà connecté en tant qu'admin, rediriger vers le panneau
        if (session != null && session.getAttribute("admin") != null) {
            response.sendRedirect(request.getContextPath() + "/AdminAnnonceServlet");
            return;
        }

        // Sinon, afficher la page de connexion
        request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
    }
}

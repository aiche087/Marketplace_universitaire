package mr.iscae.marketplace.controller;

import java.io.IOException;
import java.time.LocalDateTime;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mr.iscae.marketplace.dao.EtudiantDAO;
import mr.iscae.marketplace.model.Etudiant;
import mr.iscae.marketplace.utils.EmailUtil;
import mr.iscae.marketplace.utils.TokenUtil;

@WebServlet("/forgot-password")
public class ForgotPasswordServlet extends HttpServlet {

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String email = request.getParameter("email");

        EtudiantDAO dao = new EtudiantDAO();
        Etudiant e = dao.findByEmail(email);

        if (e != null) {
            String token = TokenUtil.generateToken();
            dao.saveToken(email, token, LocalDateTime.now().plusMinutes(30));

            String link = "http://localhost:8080/marketplace/reset-password.jsp?token=" + token;

            EmailUtil.sendEmail(email,
                    "Réinitialisation du mot de passe",
                    "Cliquez sur ce lien :\n" + link);
        }

        response.sendRedirect("forgot-password.jsp?success=true");
    }
}

package mr.iscae.marketplace.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import mr.iscae.marketplace.dao.AnnonceDAO;
import mr.iscae.marketplace.model.Annonce;
import mr.iscae.marketplace.model.Etudiant;

@WebServlet("/ModifierAnnonceServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,    // 1 MB
    maxFileSize = 1024 * 1024 * 5,      // 5 MB
    maxRequestSize = 1024 * 1024 * 10   // 10 MB
)
public class ModifierAnnonceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AnnonceDAO annonceDAO;

    @Override
    public void init() throws ServletException {
        annonceDAO = new AnnonceDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Vérifier si l'utilisateur est connecté
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("etudiant") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Etudiant etudiant = (Etudiant) session.getAttribute("etudiant");
        String message = "";
        String typeMessage = "";

        try {
            // Récupérer les paramètres
            int annonceId = Integer.parseInt(request.getParameter("id"));
            String titre = request.getParameter("titre");
            String typeService = request.getParameter("service");
            String description = request.getParameter("description");
            double prix = Double.parseDouble(request.getParameter("prix"));

            // Vérifier que les données sont valides
            if (titre == null || titre.trim().isEmpty() ||
                typeService == null || typeService.trim().isEmpty() ||
                description == null || description.trim().isEmpty()) {

                message = "Tous les champs obligatoires doivent être remplis.";
                typeMessage = "error";
                session.setAttribute("errorMessage", message);
                response.sendRedirect("modifier_annonce.jsp?id=" + annonceId);
                return;
            }

            // Récupérer l'annonce à modifier directement avec la nouvelle méthode
            Annonce annonce = annonceDAO.getAnnonceById(annonceId);

            if (annonce == null) {
                message = "Annonce non trouvée.";
                typeMessage = "error";
                session.setAttribute("errorMessage", message);
                response.sendRedirect("index.jsp");
                return;
            }

            // Vérifier que l'annonce appartient à l'étudiant
            if (annonce.getEtudiant_id() != etudiant.getId()) {
                message = "Vous n'avez pas les droits pour modifier cette annonce.";
                typeMessage = "error";
                session.setAttribute("errorMessage", message);
                response.sendRedirect("index.jsp");
                return;
            }

            // Mettre à jour les informations de l'annonce
            annonce.setTitre(titre.trim());
            annonce.setType_service(typeService.trim());
            annonce.setDescription(description.trim());
            annonce.setPrix(prix);
            annonce.setDate(new Date());

            boolean success = false;

         // Gérer le téléchargement de la nouvelle image
            Part filePart = request.getPart("nouvelleImage");
            String fileName = getFileName(filePart);

            if (fileName != null && !fileName.isEmpty()) {
                // Définir le chemin du dossier d'upload
                String uploadPath = getServletContext().getRealPath("/") + "uploads";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                // Générer un nom de fichier unique
                String uniqueFileName = System.currentTimeMillis() + "_" + fileName;

                // Créer le fichier de destination avec chemin absolu
                File fileToSave = new File(uploadDir, uniqueFileName);

                // IMPORTANT: Écrire le fichier sur le disque
                try (java.io.InputStream input = filePart.getInputStream();
                     java.io.FileOutputStream output = new java.io.FileOutputStream(fileToSave)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = input.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                    }
                }

                // Mettre à jour l'annonce avec la nouvelle image
                success = annonceDAO.updateAnnonceWithImage(annonce, "uploads/" + uniqueFileName);
                message = "Annonce et image modifiées avec succès !";
            } else {
                // Mettre à jour l'annonce sans changer l'image
                success = annonceDAO.updateAnnonce(annonce);
                message = "Annonce modifiée avec succès !";
            }

            if (success) {
                typeMessage = "success";
                session.setAttribute("successMessage", message);
                response.sendRedirect("index.jsp");
            } else {
                typeMessage = "error";
                session.setAttribute("errorMessage", "Erreur lors de la modification de l'annonce.");
                response.sendRedirect("modifier_annonce.jsp?id=" + annonceId);
            }

        } catch (NumberFormatException e) {
            message = "Données invalides. Vérifiez les valeurs saisies.";
            typeMessage = "error";
            session.setAttribute("errorMessage", message);
            response.sendRedirect("index.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            message = "Erreur technique : " + e.getMessage();
            typeMessage = "error";
            session.setAttribute("errorMessage", message);
            response.sendRedirect("index.jsp");
        }
    }

    private String getFileName(Part part) {
        if (part == null) {
            return null;
        }

        String contentDisp = part.getHeader("content-disposition");
        if (contentDisp == null) {
            return null;
        }

        String[] tokens = contentDisp.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return null;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Rediriger vers la page d'accueil si accès direct en GET
        response.sendRedirect("index.jsp");
    }
}
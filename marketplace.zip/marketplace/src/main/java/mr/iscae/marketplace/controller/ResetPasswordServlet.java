package mr.iscae.marketplace.controller;

import java.io.IOException;
import java.time.LocalDateTime;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import mr.iscae.marketplace.dao.EtudiantDAO;
import mr.iscae.marketplace.model.Etudiant;
import mr.iscae.marketplace.utils.PasswordUtil;

@WebServlet("/reset-password")
public class ResetPasswordServlet extends HttpServlet {

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String token = request.getParameter("token");
        HttpSession session = request.getSession();


        EtudiantDAO dao = new EtudiantDAO();
        Etudiant e = dao.findByToken(token);

        if (e == null || e.getTokenExpiry().isBefore(LocalDateTime.now())) {
            session.setAttribute("errorMessage", "Lien invalide ou expiré.");
            response.sendRedirect("forgot-password.jsp");
            return;
        }

        // Token valide → afficher la page JSP
        request.setAttribute("token", token);
        try {
            request.getRequestDispatcher("reset-password.jsp").forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("forgot-password.jsp");
        }
    }

    // Ton doPost existant
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String token = request.getParameter("token");
        String pass = request.getParameter("password");
        String confirm = request.getParameter("confirm");

        if (!pass.equals(confirm)) {
            response.sendRedirect("reset-password?token=" + token + "&error=true");
            return;
        }

        EtudiantDAO dao = new EtudiantDAO();
        Etudiant e = dao.findByToken(token);

        if (e == null || e.getTokenExpiry().isBefore(LocalDateTime.now())) {
            response.sendRedirect("reset-password?error=true");
            return;
        }

        dao.updatePassword(e.getEmail(), PasswordUtil.hash(pass));
        response.sendRedirect("login.jsp?reset=success");
    }
}


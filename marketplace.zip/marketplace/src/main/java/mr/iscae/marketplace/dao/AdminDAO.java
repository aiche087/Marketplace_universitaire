package mr.iscae.marketplace.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mr.iscae.marketplace.model.Admin;
import mr.iscae.marketplace.utils.DBConnection;

public class AdminDAO {

    /**
     * Recherche un admin par email pour la connexion
     */
    public Admin findByEmail(String email) {
        String sql = "SELECT * FROM admin WHERE email = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Admin admin = new Admin();
                    admin.setId(rs.getInt("id"));
                    admin.setEmail(rs.getString("email"));
                    admin.setPassword(rs.getString("password"));
                    return admin;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche de l'admin: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }

    /**
     * Vérifie si l'email et le mot de passe correspondent
     */
    public Admin authenticate(String email, String password) {
        Admin admin = findByEmail(email);
        
        if (admin != null && admin.getPassword().equals(password)) {
            return admin;
        }
        
        return null;
    }

    /*
     * Vérifie si un admin existe par ID
     */
    public boolean existsById(int id) {
        String sql = "SELECT COUNT(*) FROM admin WHERE id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Erreur lors de la vérification de l'admin: " + e.getMessage());
        }
        
        return false;
    }
}

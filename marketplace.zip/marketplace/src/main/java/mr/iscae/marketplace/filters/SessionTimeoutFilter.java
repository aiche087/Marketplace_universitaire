package mr.iscae.marketplace.filters;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter("/*")
public class SessionTimeoutFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        // Vérifier si la session a expiré
        if (session != null && session.getAttribute("etudiant") != null) {
            long now = System.currentTimeMillis();
            Long lastActivity = (Long) session.getAttribute("lastActivity");

            if (lastActivity != null) {
                long inactiveTime = now - lastActivity;
                long maxInactiveInterval = session.getMaxInactiveInterval() * 1000L;

                // Si la session a expiré
                if (inactiveTime > maxInactiveInterval) {
                    session.invalidate();

                    // Rediriger vers login avec message
                    String message = "Votre session a expiré. Veuillez vous reconnecter.";
                    res.sendRedirect(req.getContextPath() + "/login.jsp?timeout=" +
                                    java.net.URLEncoder.encode(message, "UTF-8"));
                    return;
                }
            }

            // Mettre à jour le timestamp de dernière activité
            session.setAttribute("lastActivity", now);
        }

        chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialisation
    }

    @Override
    public void destroy() {
        // Nettoyage
    }
}
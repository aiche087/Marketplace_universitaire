package mr.iscae.marketplace.filters;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Filtre pour protéger les pages d'administration
 * Vérifie que l'utilisateur est connecté en tant qu'admin
 */
@WebFilter(urlPatterns = {
    "/AdminAnnonceServlet",
    "/admin.jsp",
    "/admin/*"
})
public class AdminAuthenticationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("✅ AdminAuthenticationFilter initialisé");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        String requestURI = httpRequest.getRequestURI();
        System.out.println("🔒 AdminFilter: Vérification d'accès à " + requestURI);

        // Vérifier si l'admin est connecté
        boolean isAdminLoggedIn = (session != null 
                && session.getAttribute("admin") != null 
                && session.getAttribute("isAdmin") != null
                && (Boolean) session.getAttribute("isAdmin"));

        if (isAdminLoggedIn) {
            // ✅ Admin authentifié, continuer la requête
            System.out.println("✅ Admin authentifié, accès autorisé");
            chain.doFilter(request, response);
        } else {
            // ❌ Non authentifié, rediriger vers la page de connexion admin
            System.out.println("❌ Accès refusé, redirection vers adminLogin.jsp");
            
            if (session == null) {
                session = httpRequest.getSession();
            }
            session.setAttribute("errorMessage", "Vous devez être connecté en tant qu'administrateur");
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/adminLogin.jsp");
        }
    }

    @Override
    public void destroy() {
        System.out.println("🔴 AdminAuthenticationFilter détruit");
    }
}

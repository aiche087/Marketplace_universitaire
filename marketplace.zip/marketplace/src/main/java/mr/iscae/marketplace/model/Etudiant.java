package mr.iscae.marketplace.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Etudiant implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String nom;
    private String telephone;
    private String matricule;
    private String filiere;
    private String email;
    private String password;
    private String reset_token;
    private LocalDateTime token_expiry;

    // Constructeurs
    public Etudiant() {
    }

    public Etudiant(String nom, String telephone, String matricule, String filiere, String email, String password) {
        this.nom = nom;
        this.telephone = telephone;
        this.matricule = matricule;
        this.filiere = filiere;
        this.email = email;
        this.password = password;
    }

    // Getters et Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getFiliere() {
        return filiere;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getResetToken() {
    	return reset_token;

    }
    public void setResetToken(String resetToken) {
    	this.reset_token = reset_token;

    }

    public LocalDateTime getTokenExpiry() { return token_expiry; }
    public void setTokenExpiry(LocalDateTime token_expiry) {
        this.token_expiry = token_expiry;
    }

    @Override
    public String toString() {
        return "Etudiant [id=" + id + ", nom=" + nom + ", telephone=" + telephone + ", matricule=" + matricule
                + ", filiere=" + filiere + ", email=" + email + "]";
    }
}
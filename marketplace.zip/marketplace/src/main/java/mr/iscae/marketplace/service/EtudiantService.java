package mr.iscae.marketplace.service;

import java.util.List;

import mr.iscae.marketplace.model.Etudiant;

public interface EtudiantService {

    /**
     * Authentifier un étudiant
     * @param email l'email de l'étudiant
     * @param password le mot de passe
     * @return l'étudiant authentifié
     * @throws ServiceException si les identifiants sont incorrects ou si une erreur survient
     */
    Etudiant login(String email, String password) throws ServiceException;

    /**
     * Enregistrer un nouvel étudiant
     * @param etudiant l'étudiant à enregistrer
     * @return l'étudiant enregistré
     * @throws ServiceException si l'email existe déjà ou si une erreur survient
     */
    Etudiant register(Etudiant etudiant) throws ServiceException;

    /**
     * Récupérer tous les étudiants
     * @return liste des étudiants
     * @throws ServiceException si une erreur survient
     */
    List<Etudiant> getAllEtudiants() throws ServiceException;

    /**
     * Récupérer un étudiant par son ID
     * @param id l'ID de l'étudiant
     * @return l'étudiant correspondant
     * @throws ServiceException si l'étudiant n'existe pas ou si une erreur survient
     */
    Etudiant getEtudiantById(int id) throws ServiceException;

    /**
     * Mettre à jour les informations d'un étudiant
     * @param etudiant l'étudiant avec les nouvelles informations
     * @return l'étudiant mis à jour
     * @throws ServiceException si l'étudiant n'existe pas ou si une erreur survient
     */
    Etudiant updateEtudiant(Etudiant etudiant) throws ServiceException;

    /**
     * Changer le mot de passe d'un étudiant
     * @param etudiantId l'ID de l'étudiant
     * @param ancienMotDePasse l'ancien mot de passe
     * @param nouveauMotDePasse le nouveau mot de passe
     * @return true si le changement a réussi
     * @throws ServiceException si l'ancien mot de passe est incorrect ou si une erreur survient
     */
    boolean changePassword(int etudiantId, String ancienMotDePasse, String nouveauMotDePasse) throws ServiceException;

    /**
     * Vérifier si un email existe déjà
     * @param email l'email à vérifier
     * @return true si l'email existe
     * @throws ServiceException si une erreur survient
     */
    boolean emailExists(String email) throws ServiceException;
}
package mr.iscae.marketplace.controller;

import java.io.File;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import mr.iscae.marketplace.dao.AnnonceDAO;
import mr.iscae.marketplace.model.Annonce;
import mr.iscae.marketplace.model.Etudiant;

@WebServlet("/AjouterAnnonceServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50    // 50MB
)
public class AjouterAnnonceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AnnonceDAO annonceDAO;

    @Override
    public void init() throws ServletException {
        annonceDAO = new AnnonceDAO();
    }

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Vérifier si l'utilisateur est connecté
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("etudiant") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Etudiant etudiant = (Etudiant) session.getAttribute("etudiant");

        // Récupérer les paramètres du formulaire
        String titre = request.getParameter("titre");
        String type_service = request.getParameter("service");
        String description = request.getParameter("description");
        String prixStr = request.getParameter("prix");

        // Validation
        if (titre == null || titre.trim().isEmpty() ||
            type_service == null || type_service.trim().isEmpty() ||
            description == null || description.trim().isEmpty()) {

            request.setAttribute("errorMessage", "Veuillez remplir tous les champs obligatoires");
            request.getRequestDispatcher("ajouter_annonce.jsp").forward(request, response);
            return;
        }

        double prix = 0.0;
        try {
            if (prixStr != null && !prixStr.trim().isEmpty()) {
                prix = Double.parseDouble(prixStr);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Prix invalide");
            request.getRequestDispatcher("ajouter_annonce.jsp").forward(request, response);
            return;
        }
     // Gestion de l'upload d'image

     // Définir le chemin du dossier d'upload dans le répertoire de l'application déployée
     String uploadDirPath = getServletContext().getRealPath("/") + "uploads";
     String imagePath = "";

     // Créer le dossier s'il n'existe pas
     File uploadDir = new File(uploadDirPath);
     if (!uploadDir.exists()) {
         uploadDir.mkdirs();
     }

     // Récupérer le fichier uploadé
     Part filePart = request.getPart("image");
     if (filePart != null && filePart.getSize() > 0) {
         // Générer un nom unique pour le fichier
         String fileName = System.currentTimeMillis() + "_" + getFileName(filePart);

         // Créer le fichier de destination avec chemin absolu
         File fileToSave = new File(uploadDir, fileName);

         // IMPORTANT: Écrire le fichier sur le disque
         try (java.io.InputStream input = filePart.getInputStream();
              java.io.FileOutputStream output = new java.io.FileOutputStream(fileToSave)) {
             byte[] buffer = new byte[1024];
             int bytesRead;
             while ((bytesRead = input.read(buffer)) != -1) {
                 output.write(buffer, 0, bytesRead);
             }
         }

         // Stocker le chemin relatif pour la base de données
         imagePath = "uploads/" + fileName;
     }

        // Créer l'objet Annonce
        Annonce annonce = new Annonce();
        annonce.setTitre(titre);
        annonce.setType_service(type_service);
        annonce.setDescription(description);
        annonce.setPrix(prix);
        annonce.setImage(imagePath);
        annonce.setEtudiant_id(etudiant.getId());

        // S'assurer que la date est définie
        if (annonce.getDate() == null) {
            annonce.setDate(new java.util.Date());
        }

        // Ajouter l'annonce à la base de données
        boolean success = annonceDAO.addAnnonce(annonce);

        if (success) {
            request.setAttribute("successMessage", "Annonce publiée avec succès!");
            response.sendRedirect("index.jsp");
        } else {
            request.setAttribute("errorMessage", "Erreur lors de la publication de l'annonce");
            request.getRequestDispatcher("ajouter_annonce.jsp").forward(request, response);
        }
    }

    // Méthode utilitaire pour récupérer le nom du fichier
    private String getFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        if (contentDisp != null) {
            String[] tokens = contentDisp.split(";");
            for (String token : tokens) {
                if (token.trim().startsWith("filename")) {
                    return token.substring(token.indexOf("=") + 2, token.length() - 1);
                }
            }
        }
        return "unknown";
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Vérifier si l'utilisateur est connecté
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("etudiant") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        request.getRequestDispatcher("ajouter_annonce.jsp").forward(request, response);
    }
}
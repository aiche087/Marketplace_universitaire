package mr.iscae.marketplace.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mr.iscae.marketplace.dao.AnnonceDAO;
import mr.iscae.marketplace.model.Annonce;

@WebServlet("/AdminAnnonceServlet")
public class AdminAnnonceServlet extends HttpServlet {

    private AnnonceDAO annonceDAO = new AnnonceDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Annonce> annonces = annonceDAO.getAllAnnonces();
        request.setAttribute("annonces", annonces);
        request.getRequestDispatcher("admin.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int annonceId = Integer.parseInt(request.getParameter("id"));
        annonceDAO.deleteAnnonceByAdmin(annonceId);

        response.sendRedirect(request.getContextPath() + "/AdminAnnonceServlet");
    }
}

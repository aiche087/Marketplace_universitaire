package mr.iscae.marketplace.dao;

// Ceci importe java.sql.Date, java.sql.Timestamp, etc.
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import mr.iscae.marketplace.model.Annonce;
import mr.iscae.marketplace.utils.DBConnection;

public class AnnonceDAO {

    // Méthode pour ajouter une annonce
    public boolean addAnnonce(Annonce annonce) {
        // Utiliser CURRENT_TIMESTAMP pour que MySQL gère la date automatiquement
        String sql = "INSERT INTO annonce (titre, date, type_service, description, prix, image, etudiant_id) VALUES (?, CURRENT_TIMESTAMP, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, annonce.getTitre());
            pstmt.setString(2, annonce.getType_service());
            pstmt.setString(3, annonce.getDescription());
            pstmt.setDouble(4, annonce.getPrix());
            pstmt.setString(5, annonce.getImage());
            pstmt.setInt(6, annonce.getEtudiant_id());

            int rowsAffected = pstmt.executeUpdate();

            // Récupérer l'ID généré
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        annonce.setId(generatedKeys.getInt(1));
                    }
                }
            }

            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout de l'annonce: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Méthode alternative si vous voulez passer la date explicitement
    public boolean addAnnonceWithDate(Annonce annonce) {
        String sql = "INSERT INTO annonce (titre, date, type_service, description, prix, image, etudiant_id) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, annonce.getTitre());

            // S'assurer que la date n'est pas null - utiliser java.util.Date
            java.util.Date utilDate = annonce.getDate();
            if (utilDate == null) {
                utilDate = new java.util.Date();
                annonce.setDate(utilDate);
            }
            // Convertir java.util.Date en java.sql.Timestamp
            pstmt.setTimestamp(2, new Timestamp(utilDate.getTime()));

            pstmt.setString(3, annonce.getType_service());
            pstmt.setString(4, annonce.getDescription());
            pstmt.setDouble(5, annonce.getPrix());
            pstmt.setString(6, annonce.getImage());
            pstmt.setInt(7, annonce.getEtudiant_id());

            int rowsAffected = pstmt.executeUpdate();

            // Récupérer l'ID généré
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        annonce.setId(generatedKeys.getInt(1));
                    }
                }
            }

            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout de l'annonce: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

	/*
	 * // Méthode pour récupérer toutes les annonces public List<Annonce>
	 * getAllAnnonces() { List<Annonce> annonces = new ArrayList<>(); String sql =
	 * "SELECT a.*, e.nom, e.telephone FROM annonce a JOIN etudiant e ON a.etudiant_id = e.id ORDER BY a.date DESC"
	 * ;
	 *
	 * try (Connection conn = DBConnection.getConnection(); Statement stmt =
	 * conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
	 *
	 * while (rs.next()) { Annonce annonce = new Annonce();
	 * annonce.setId(rs.getInt("id")); annonce.setTitre(rs.getString("titre"));
	 *
	 * // Convertir java.sql.Timestamp en java.util.Date Timestamp timestamp =
	 * rs.getTimestamp("date"); if (timestamp != null) { annonce.setDate(new
	 * java.util.Date(timestamp.getTime())); }
	 *
	 * annonce.setType_service(rs.getString("type_service"));
	 * annonce.setDescription(rs.getString("description"));
	 * annonce.setPrix(rs.getDouble("prix"));
	 * annonce.setImage(rs.getString("image"));
	 * annonce.setEtudiant_id(rs.getInt("etudiant_id"));
	 *
	 * annonces.add(annonce); } } catch (SQLException e) {
	 * System.err.println("Erreur lors de la récupération des annonces: " +
	 * e.getMessage()); e.printStackTrace(); }
	 *
	 * return annonces; }
	 */

    // Méthode pour compter les annonces
    public int countAnnonces() {
        String sql = "SELECT COUNT(*) FROM annonce";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors du comptage des annonces: " + e.getMessage());
            e.printStackTrace();
        }

        return 0;
    }

    // Méthode pour récupérer les annonces par type de service
    public List<Annonce> getAnnoncesByService(String service) {
        List<Annonce> annonces = new ArrayList<>();
        String sql = "SELECT a.*, e.nom, e.telephone FROM annonce a JOIN etudiant e ON a.etudiant_id = e.id WHERE a.type_service = ? ORDER BY a.date DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, service);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Annonce annonce = new Annonce();
                annonce.setId(rs.getInt("id"));
                annonce.setTitre(rs.getString("titre"));

                // Convertir java.sql.Timestamp en java.util.Date
                Timestamp timestamp = rs.getTimestamp("date");
                if (timestamp != null) {
                    annonce.setDate(new java.util.Date(timestamp.getTime()));
                }

                annonce.setType_service(rs.getString("type_service"));
                annonce.setDescription(rs.getString("description"));
                annonce.setPrix(rs.getDouble("prix"));
                annonce.setImage(rs.getString("image"));
                annonce.setEtudiant_id(rs.getInt("etudiant_id"));

                annonces.add(annonce);
            }

            rs.close();
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des annonces par service: " + e.getMessage());
            e.printStackTrace();
        }

        return annonces;
    }

    // Méthode pour rechercher des annonces
    public List<Annonce> searchAnnonces(String keyword) {
        List<Annonce> annonces = new ArrayList<>();
        String sql = "SELECT a.*, e.nom, e.telephone FROM annonce a JOIN etudiant e ON a.etudiant_id = e.id WHERE a.titre LIKE ? OR a.description LIKE ? ORDER BY a.date DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setString(2, "%" + keyword + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Annonce annonce = new Annonce();
                annonce.setId(rs.getInt("id"));
                annonce.setTitre(rs.getString("titre"));

                // Convertir java.sql.Timestamp en java.util.Date
                Timestamp timestamp = rs.getTimestamp("date");
                if (timestamp != null) {
                    annonce.setDate(new java.util.Date(timestamp.getTime()));
                }

                annonce.setType_service(rs.getString("type_service"));
                annonce.setDescription(rs.getString("description"));
                annonce.setPrix(rs.getDouble("prix"));
                annonce.setImage(rs.getString("image"));
                annonce.setEtudiant_id(rs.getInt("etudiant_id"));

                annonces.add(annonce);
            }

            rs.close();
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche d'annonces: " + e.getMessage());
            e.printStackTrace();
        }

        return annonces;
    }

    // Méthode pour récupérer le nom de l'étudiant
    public String getEtudiantName(int etudiantId) {
        String sql = "SELECT nom FROM etudiant WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, etudiantId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getString("nom");
            }

            rs.close();
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération du nom de l'étudiant: " + e.getMessage());
            e.printStackTrace();
        }

        return "Inconnu";
    }

    // Méthode pour récupérer le téléphone de l'étudiant
    public String getEtudiantPhone(int etudiantId) {
        String sql = "SELECT telephone FROM etudiant WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, etudiantId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getString("telephone");
            }

            rs.close();
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération du téléphone de l'étudiant: " + e.getMessage());
            e.printStackTrace();
        }

        return "Non disponible";
    }
 // Méthode pour mettre à jour une annonce
    public boolean updateAnnonce(Annonce annonce) {
        String sql = "UPDATE annonce SET titre = ?, type_service = ?, description = ?, prix = ?, date = NOW() WHERE id = ? AND etudiant_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, annonce.getTitre());
            pstmt.setString(2, annonce.getType_service());
            pstmt.setString(3, annonce.getDescription());
            pstmt.setDouble(4, annonce.getPrix());
            pstmt.setInt(5, annonce.getId());
            pstmt.setInt(6, annonce.getEtudiant_id());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Erreur lors de la mise à jour de l'annonce: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Méthode pour mettre à jour une annonce avec image
    public boolean updateAnnonceWithImage(Annonce annonce, String imagePath) {
        String sql = "UPDATE annonce SET titre = ?, type_service = ?, description = ?, prix = ?, image = ?, date = NOW() WHERE id = ? AND etudiant_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, annonce.getTitre());
            pstmt.setString(2, annonce.getType_service());
            pstmt.setString(3, annonce.getDescription());
            pstmt.setDouble(4, annonce.getPrix());
            pstmt.setString(5, imagePath);
            pstmt.setInt(6, annonce.getId());
            pstmt.setInt(7, annonce.getEtudiant_id());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Erreur lors de la mise à jour de l'annonce avec image: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Méthode pour supprimer une annonce
    public boolean deleteAnnonce(int annonceId, int etudiantId) {
        String sql = "DELETE FROM annonce WHERE id = ? AND etudiant_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, annonceId);
            pstmt.setInt(2, etudiantId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression de l'annonce: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Méthode pour récupérer une annonce par son ID (optimisée)
    public Annonce getAnnonceById(int id) {
        String sql = "SELECT * FROM annonce WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Annonce annonce = new Annonce();
                annonce.setId(rs.getInt("id"));
                annonce.setTitre(rs.getString("titre"));

                Timestamp timestamp = rs.getTimestamp("date");
                if (timestamp != null) {
                    annonce.setDate(new java.util.Date(timestamp.getTime()));
                }

                annonce.setType_service(rs.getString("type_service"));
                annonce.setDescription(rs.getString("description"));
                annonce.setPrix(rs.getDouble("prix"));
                annonce.setImage(rs.getString("image"));
                annonce.setEtudiant_id(rs.getInt("etudiant_id"));

                rs.close();
                return annonce;
            }

            rs.close();
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération de l'annonce par ID: " + e.getMessage());
            e.printStackTrace();
        }

        return null;
    }


    // Modifier getAllAnnonces pour récupérer le status
    public List<Annonce> getAllAnnonces() {
        List<Annonce> annonces = new ArrayList<>();
        String sql = "SELECT a.*, e.nom, e.telephone FROM annonce a JOIN etudiant e ON a.etudiant_id = e.id ORDER BY a.date DESC";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Annonce annonce = new Annonce();
                annonce.setId(rs.getInt("id"));
                annonce.setTitre(rs.getString("titre"));
                Timestamp timestamp = rs.getTimestamp("date");
                if (timestamp != null) {
					annonce.setDate(new java.util.Date(timestamp.getTime()));
				}
                annonce.setType_service(rs.getString("type_service"));
                annonce.setDescription(rs.getString("description"));
                annonce.setPrix(rs.getDouble("prix"));
                annonce.setImage(rs.getString("image"));
                annonce.setEtudiant_id(rs.getInt("etudiant_id"));

                annonces.add(annonce);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return annonces;
    }


 // Compter le nombre d'annonces par type de service
    public int countAnnoncesByType(String type) {
        String sql = "SELECT COUNT(*) FROM annonce WHERE type_service = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, type);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }



 // Suppression d'une annonce par l'admin
    public boolean deleteAnnonceByAdmin(int annonceId) {
        String sql = "DELETE FROM annonce WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, annonceId);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


}
package mr.iscae.marketplace.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import mr.iscae.marketplace.model.Etudiant;
import mr.iscae.marketplace.utils.DBConnection;

public class EtudiantDAO {

    // Méthode pour vérifier les informations de connexion
	public Etudiant findByEmailForLogin(String email) {
	    String sql = "SELECT * FROM etudiant WHERE email = ?";
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, email);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            Etudiant e = new Etudiant();
	            e.setId(rs.getInt("id"));
	            e.setNom(rs.getString("nom"));
	            e.setEmail(rs.getString("email"));
	            e.setPassword(rs.getString("password")); // hash OU clair
	            return e;
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return null;
	}


    // Méthode pour enregistrer un nouvel étudiant
    public boolean register(Etudiant etudiant) {
        String sql = "INSERT INTO etudiant (nom, telephone, matricule, filiere, email, password) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, etudiant.getNom());
            pstmt.setString(2, etudiant.getTelephone());
            pstmt.setString(3, etudiant.getMatricule());
            pstmt.setString(4, etudiant.getFiliere());
            pstmt.setString(5, etudiant.getEmail());
            pstmt.setString(6, etudiant.getPassword());

            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'inscription: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Vérifier si l'email existe déjà
    public boolean emailExists(String email) {
        String sql = "SELECT COUNT(*) FROM etudiant WHERE email = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

            rs.close();
        } catch (SQLException e) {
            System.err.println("Erreur lors de la vérification de l'email: " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }

    // Récupérer tous les étudiants
    public List<Etudiant> getAllEtudiants() {
        List<Etudiant> etudiants = new ArrayList<>();
        String sql = "SELECT * FROM etudiant";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Etudiant etudiant = new Etudiant();
                etudiant.setId(rs.getInt("id"));
                etudiant.setNom(rs.getString("nom"));
                etudiant.setTelephone(rs.getString("telephone"));
                etudiant.setMatricule(rs.getString("matricule"));
                etudiant.setFiliere(rs.getString("filiere"));
                etudiant.setEmail(rs.getString("email"));
                etudiant.setPassword(rs.getString("password"));

                etudiants.add(etudiant);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des étudiants: " + e.getMessage());
            e.printStackTrace();
        }

        return etudiants;
    }

    // Compter le nombre d'étudiants
    public int countEtudiants() {
        String sql = "SELECT COUNT(*) FROM etudiant";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors du comptage des étudiants: " + e.getMessage());
            e.printStackTrace();
        }

        return 0;
    }

    //
    public Etudiant findByEmail(String email) {
        String sql = "SELECT * FROM etudiant WHERE email=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Etudiant e = new Etudiant();
                e.setEmail(email);
                return e;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void saveToken(String email, String token, LocalDateTime expiry) {
        String sql = "UPDATE etudiant SET reset_token=?, token_expiry=? WHERE email=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, token);
            ps.setTimestamp(2, Timestamp.valueOf(expiry));
            ps.setString(3, email);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Etudiant findByToken(String token) {
        String sql = "SELECT * FROM etudiant WHERE reset_token=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, token);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Etudiant e = new Etudiant();
                e.setEmail(rs.getString("email"));
                e.setTokenExpiry(rs.getTimestamp("token_expiry").toLocalDateTime());
                return e;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updatePassword(String email, String password) {
        String sql = """
            UPDATE etudiant
            SET password=?, reset_token=NULL, token_expiry=NULL
            WHERE email=?
        """;
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, password);
            ps.setString(2, email);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
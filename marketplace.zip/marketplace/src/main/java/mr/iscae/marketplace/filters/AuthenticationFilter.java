package mr.iscae.marketplace.filters;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter("/*")
public class AuthenticationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        String requestURI = req.getRequestURI();
        String contextPath = req.getContextPath();

        // Déterminer si l'utilisateur est connecté
        boolean isLoggedIn = (session != null && session.getAttribute("etudiant") != null);

        // Pages publiques (accessibles sans connexion)
        boolean isPublicPage =
            requestURI.endsWith(contextPath + "/") ||
            requestURI.endsWith(contextPath + "/index.jsp") ||
            requestURI.endsWith(contextPath + "/login.jsp") ||
            requestURI.endsWith(contextPath + "/adminLogin.jsp") ||
            requestURI.endsWith(contextPath + "/LoginServlet") ||
            requestURI.endsWith(contextPath + "/register.jsp") ||
            requestURI.endsWith(contextPath + "/RegisterServlet") ||
            requestURI.endsWith(contextPath + "/LogoutServlet") ||
            requestURI.contains("/uploads/") ||
            requestURI.endsWith(".css") ||
            requestURI.endsWith(".js") ||



















































































            requestURI.endsWith(".png") ||
            requestURI.endsWith(".jpg") ||
            requestURI.endsWith(".jpeg") ||
            requestURI.endsWith(".gif") ||
            requestURI.endsWith(".ico") ||
            requestURI.endsWith(".svg") ||
            requestURI.endsWith(".woff") ||
            requestURI.endsWith(".woff2") ||
            requestURI.endsWith(".ttf");

        // Pages protégées (nécessitent une connexion)
        boolean isProtectedPage =
            requestURI.endsWith(contextPath + "/ajouter_annonce.jsp") ||
            requestURI.endsWith(contextPath + "/AjouterAnnonceServlet") ||
            requestURI.endsWith(contextPath + "/modifier_annonce.jsp") ||
            requestURI.endsWith(contextPath + "/ModifierAnnonceServlet") ||
            requestURI.endsWith(contextPath + "/SupprimerAnnonceServlet") ||
            requestURI.contains("/admin/") ;

        // Règles de sécurité :

        // 1. Si l'utilisateur est connecté et tente d'accéder à login/register, rediriger vers l'accueil
        if (isLoggedIn &&
            (requestURI.endsWith(contextPath + "/login.jsp") ||
             requestURI.endsWith(contextPath + "/LoginServlet") ||
             requestURI.endsWith(contextPath + "/register.jsp") ||
             requestURI.endsWith(contextPath + "/RegisterServlet"))) {

            res.sendRedirect(contextPath + "/index.jsp");
            return;
        }

        // 2. Si l'utilisateur n'est pas connecté et tente d'accéder à une page protégée
        if (!isLoggedIn && isProtectedPage) {
            // Stocker l'URL demandée pour redirection après login
            if (session == null) {
                session = req.getSession(true);
            }
            session.setAttribute("redirectAfterLogin", requestURI);

            res.sendRedirect(contextPath + "/login.jsp");
            return;
        }

        // 3. Sécurité supplémentaire : Vérifier les paramètres ID pour modification/suppression
        if (isLoggedIn && (requestURI.contains("modifier_annonce.jsp") ||
                          requestURI.endsWith("ModifierAnnonceServlet") ||
                          requestURI.endsWith("SupprimerAnnonceServlet"))) {

            // Vérifier que l'utilisateur possède bien l'annonce qu'il tente de modifier/supprimer
            if (req.getParameter("id") != null) {
                try {
                    int annonceId = Integer.parseInt(req.getParameter("id"));
                    mr.iscae.marketplace.dao.AnnonceDAO annonceDAO = new mr.iscae.marketplace.dao.AnnonceDAO();
                    mr.iscae.marketplace.model.Annonce annonce = annonceDAO.getAnnonceById(annonceId);

                    if (annonce != null) {
                        mr.iscae.marketplace.model.Etudiant etudiant =
                            (mr.iscae.marketplace.model.Etudiant) session.getAttribute("etudiant");

                        // Si l'annonce n'appartient pas à l'utilisateur connecté
                        if (annonce.getEtudiant_id() != etudiant.getId()) {
                            session.setAttribute("errorMessage", "Vous n'avez pas les droits pour modifier/supprimer cette annonce.");
                            res.sendRedirect(contextPath + "/index.jsp");
                            return;
                        }
                    }
                } catch (Exception e) {
                    // En cas d'erreur, rediriger vers l'accueil
                    session.setAttribute("errorMessage", "Annonce non valide.");
                    res.sendRedirect(contextPath + "/index.jsp");
                    return;
                }
            }
        }



        // 5. Empêcher la mise en cache des pages sécurisées
        if (isProtectedPage || requestURI.endsWith("LogoutServlet")) {
            res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            res.setHeader("Pragma", "no-cache");
            res.setHeader("Expires", "0");
        }

        // Continuer la chaîne de filtres
        chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialisation si nécessaire
    }

    @Override
    public void destroy() {
        // Nettoyage si nécessaire
    }
}
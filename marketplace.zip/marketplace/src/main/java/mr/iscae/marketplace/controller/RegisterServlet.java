package mr.iscae.marketplace.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mr.iscae.marketplace.dao.EtudiantDAO;
import mr.iscae.marketplace.model.Etudiant;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private EtudiantDAO etudiantDAO;

    @Override
    public void init() throws ServletException {
        etudiantDAO = new EtudiantDAO();
    }

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Récupérer les paramètres du formulaire
        String nom = request.getParameter("nom");
        String telephone = request.getParameter("phone");
        String matricule = request.getParameter("matricule");
        String filiere = request.getParameter("filiere");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validation des données
        StringBuilder errors = new StringBuilder();

        if (nom == null || nom.trim().isEmpty()) {
            errors.append("Le nom est obligatoire<br>");
        }

        if (telephone == null || telephone.trim().isEmpty()) {
            errors.append("Le téléphone est obligatoire<br>");
        }

        if (matricule == null || matricule.trim().isEmpty()) {
            errors.append("Le matricule est obligatoire<br>");
        }

        if (filiere == null || filiere.trim().isEmpty()) {
            errors.append("La filière est obligatoire<br>");
        }

        if (email == null || email.trim().isEmpty() || !email.contains("@")) {
            errors.append("Email invalide<br>");
        }

        if (password == null || password.trim().length() < 6) {
            errors.append("Le mot de passe doit contenir au moins 6 caractères<br>");
        }

        // Vérifier si l'email existe déjà
        if (etudiantDAO.emailExists(email)) {
            errors.append("Cet email est déjà utilisé<br>");
        }

        // Si il y a des erreurs
        if (errors.length() > 0) {
            request.setAttribute("errorMessage", errors.toString());
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // Créer l'objet Etudiant
        Etudiant etudiant = new Etudiant();
        etudiant.setNom(nom);
        etudiant.setTelephone(telephone);
        etudiant.setMatricule(matricule);
        etudiant.setFiliere(filiere);
        etudiant.setEmail(email);
        etudiant.setPassword(password);

        // Enregistrer l'étudiant
        boolean success = etudiantDAO.register(etudiant);

        if (success) {
            // Rediriger vers la page de login avec un message de succès
            request.setAttribute("successMessage", "Inscription réussie! Vous pouvez maintenant vous connecter.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            request.setAttribute("errorMessage", "Erreur lors de l'inscription. Veuillez réessayer.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("register.jsp");
    }
}
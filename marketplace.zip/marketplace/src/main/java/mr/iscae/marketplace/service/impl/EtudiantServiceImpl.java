package mr.iscae.marketplace.service.impl;

import java.util.List;
import java.util.regex.Pattern;

import mr.iscae.marketplace.dao.EtudiantDAO;
import mr.iscae.marketplace.model.Etudiant;
import mr.iscae.marketplace.service.EtudiantService;
import mr.iscae.marketplace.service.ServiceException;

public class EtudiantServiceImpl implements EtudiantService {

    private EtudiantDAO etudiantDAO;

    // Patterns pour la validation
    private static final Pattern EMAIL_PATTERN =
        Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    private static final Pattern PHONE_PATTERN =
        Pattern.compile("^[2-4][0-9]{8}$");
    private static final Pattern MATRICULE_PATTERN =
        Pattern.compile("^[I]{2}[0-9]{4,6}$");

    public EtudiantServiceImpl() {
        this.etudiantDAO = new EtudiantDAO();
    }

    // Pour les tests unitaires
    public EtudiantServiceImpl(EtudiantDAO etudiantDAO) {
        this.etudiantDAO = etudiantDAO;
    }

    @Override
    public Etudiant login(String email, String password) throws ServiceException {
        try {
            // Validation des entrées
            if (email == null || email.trim().isEmpty()) {
                throw new ServiceException("L'email est obligatoire",
                    ServiceException.ErrorType.VALIDATION_ERROR);
            }

            if (password == null || password.trim().isEmpty()) {
                throw new ServiceException("Le mot de passe est obligatoire",
                    ServiceException.ErrorType.VALIDATION_ERROR);
            }

            if (!EMAIL_PATTERN.matcher(email).matches()) {
                throw new ServiceException("Format d'email invalide",
                    ServiceException.ErrorType.VALIDATION_ERROR);
            }

            // Authentification
            Etudiant etudiant = etudiantDAO.findByEmailForLogin(email);

            if (etudiant == null) {
                throw new ServiceException("Email ou mot de passe incorrect",
                    ServiceException.ErrorType.AUTHENTICATION_ERROR);
            }

            return etudiant;

        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de l'authentification: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public Etudiant register(Etudiant etudiant) throws ServiceException {
        try {
            // Validation des données
            validateEtudiant(etudiant);

            // Vérifier si l'email existe déjà
            if (emailExists(etudiant.getEmail())) {
                throw new ServiceException("Cet email est déjà utilisé",
                    ServiceException.ErrorType.DUPLICATE_ENTRY);
            }

            // Enregistrer l'étudiant
            boolean success = etudiantDAO.register(etudiant);

            if (!success) {
                throw new ServiceException("Erreur lors de l'inscription",
                    ServiceException.ErrorType.DATABASE_ERROR);
            }

            return etudiant;

        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de l'inscription: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public List<Etudiant> getAllEtudiants() throws ServiceException {
        try {
            return etudiantDAO.getAllEtudiants();
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la récupération des étudiants: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public Etudiant getEtudiantById(int id) throws ServiceException {
        try {
            // Note: Vous devez ajouter cette méthode dans votre EtudiantDAO
            // Pour l'instant, je vais simuler la logique

            List<Etudiant> etudiants = getAllEtudiants();
            for (Etudiant etudiant : etudiants) {
                if (etudiant.getId() == id) {
                    return etudiant;
                }
            }

            throw new ServiceException("Étudiant non trouvé avec l'ID: " + id,
                ServiceException.ErrorType.NOT_FOUND);

        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la récupération de l'étudiant: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public Etudiant updateEtudiant(Etudiant etudiant) throws ServiceException {
        try {
            // Validation des données
            validateEtudiant(etudiant);

            // Vérifier que l'étudiant existe
            Etudiant existing = getEtudiantById(etudiant.getId());
            if (existing == null) {
                throw new ServiceException("Étudiant non trouvé",
                    ServiceException.ErrorType.NOT_FOUND);
            }

            // Vérifier si l'email a changé et s'il existe déjà
            if (!existing.getEmail().equals(etudiant.getEmail()) &&
                emailExists(etudiant.getEmail())) {
                throw new ServiceException("Cet email est déjà utilisé",
                    ServiceException.ErrorType.DUPLICATE_ENTRY);
            }

            // Mettre à jour l'étudiant
            boolean success = updateEtudiantInDAO(etudiant);

            if (!success) {
                throw new ServiceException("Erreur lors de la mise à jour de l'étudiant",
                    ServiceException.ErrorType.DATABASE_ERROR);
            }

            return etudiant;

        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la mise à jour de l'étudiant: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public boolean changePassword(int etudiantId, String ancienMotDePasse, String nouveauMotDePasse) throws ServiceException {
        try {
            // Validation
            if (ancienMotDePasse == null || ancienMotDePasse.trim().isEmpty()) {
                throw new ServiceException("L'ancien mot de passe est obligatoire",
                    ServiceException.ErrorType.VALIDATION_ERROR);
            }

            if (nouveauMotDePasse == null || nouveauMotDePasse.trim().length() < 6) {
                throw new ServiceException("Le nouveau mot de passe doit contenir au moins 6 caractères",
                    ServiceException.ErrorType.VALIDATION_ERROR);
            }

            // Vérifier l'ancien mot de passe
            Etudiant etudiant = getEtudiantById(etudiantId);
            if (!etudiant.getPassword().equals(ancienMotDePasse)) {
                throw new ServiceException("Ancien mot de passe incorrect",
                    ServiceException.ErrorType.AUTHENTICATION_ERROR);
            }

            // Changer le mot de passe
            boolean success = changePasswordInDAO(etudiantId, nouveauMotDePasse);

            if (!success) {
                throw new ServiceException("Erreur lors du changement de mot de passe",
                    ServiceException.ErrorType.DATABASE_ERROR);
            }

            return true;

        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors du changement de mot de passe: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public boolean emailExists(String email) throws ServiceException {
        try {
            if (email == null || email.trim().isEmpty()) {
                return false;
            }

            return etudiantDAO.emailExists(email);
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la vérification de l'email: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    // Méthode privée pour la validation
    private void validateEtudiant(Etudiant etudiant) throws ServiceException {
        if (etudiant == null) {
            throw new ServiceException("L'étudiant ne peut pas être nul",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (etudiant.getNom() == null || etudiant.getNom().trim().isEmpty()) {
            throw new ServiceException("Le nom est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (etudiant.getNom().length() > 50) {
            throw new ServiceException("Le nom ne doit pas dépasser 50 caractères",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (etudiant.getTelephone() == null || etudiant.getTelephone().trim().isEmpty()) {
            throw new ServiceException("Le téléphone est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (!PHONE_PATTERN.matcher(etudiant.getTelephone()).matches()) {
            throw new ServiceException("Format de téléphone invalide. Utilisez le format marocain",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (etudiant.getMatricule() == null || etudiant.getMatricule().trim().isEmpty()) {
            throw new ServiceException("Le matricule est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (!MATRICULE_PATTERN.matcher(etudiant.getMatricule()).matches()) {
            throw new ServiceException("Format de matricule invalide",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (etudiant.getFiliere() == null || etudiant.getFiliere().trim().isEmpty()) {
            throw new ServiceException("La filière est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (etudiant.getEmail() == null || etudiant.getEmail().trim().isEmpty()) {
            throw new ServiceException("L'email est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (!EMAIL_PATTERN.matcher(etudiant.getEmail()).matches()) {
            throw new ServiceException("Format d'email invalide",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (etudiant.getPassword() == null || etudiant.getPassword().trim().length() < 6) {
            throw new ServiceException("Le mot de passe doit contenir au moins 6 caractères",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }
    }

    // Méthodes temporaires (à implémenter dans EtudiantDAO)
    private boolean updateEtudiantInDAO(Etudiant etudiant) {
        // Implémentation temporaire - à remplacer par votre logique DAO
        System.out.println("Mise à jour de l'étudiant avec ID: " + etudiant.getId());
        return true;
    }

    private boolean changePasswordInDAO(int etudiantId, String nouveauMotDePasse) {
        // Implémentation temporaire - à remplacer par votre logique DAO
        System.out.println("Changement de mot de passe pour l'étudiant ID: " + etudiantId);
        return true;
    }
}
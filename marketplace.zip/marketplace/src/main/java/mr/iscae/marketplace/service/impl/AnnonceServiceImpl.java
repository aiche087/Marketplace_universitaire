package mr.iscae.marketplace.service.impl;

import java.util.Date;
import java.util.List;

import mr.iscae.marketplace.dao.AnnonceDAO;
import mr.iscae.marketplace.dao.EtudiantDAO;
import mr.iscae.marketplace.model.Annonce;
import mr.iscae.marketplace.service.AnnonceService;
import mr.iscae.marketplace.service.ServiceException;

public class AnnonceServiceImpl implements AnnonceService {

    private AnnonceDAO annonceDAO;
    private EtudiantDAO etudiantDAO;

    public AnnonceServiceImpl() {
        this.annonceDAO = new AnnonceDAO();
        this.etudiantDAO = new EtudiantDAO();
    }



    // Pour les tests unitaires
    public AnnonceServiceImpl(AnnonceDAO annonceDAO, EtudiantDAO etudiantDAO) {
        this.annonceDAO = annonceDAO;
        this.etudiantDAO = etudiantDAO;
    }

    @Override
    public Annonce addAnnonce(Annonce annonce) throws ServiceException {
        try {
            // Validation des données
            validateAnnonce(annonce);



            // Définir la date actuelle si non définie
            if (annonce.getDate() == null) {
                annonce.setDate(new Date());
            }

            // Ajouter l'annonce
            boolean success = annonceDAO.addAnnonce(annonce);

            if (!success) {
                throw new ServiceException("Erreur lors de l'ajout de l'annonce",
                    ServiceException.ErrorType.DATABASE_ERROR);
            }

            return annonce;

        } catch (Exception e) {
            if (e instanceof ServiceException) {
                throw (ServiceException) e;
            }
            throw new ServiceException("Erreur lors de l'ajout de l'annonce: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public List<Annonce> getAllAnnonces() throws ServiceException {
        try {
            return annonceDAO.getAllAnnonces();
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la récupération des annonces: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public List<Annonce> getAnnoncesByService(String service) throws ServiceException {
        try {
            if (service == null || service.trim().isEmpty()) {
                throw new ServiceException("Le type de service ne peut pas être vide",
                    ServiceException.ErrorType.VALIDATION_ERROR);
            }

            return annonceDAO.getAnnoncesByService(service);
        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la récupération des annonces par service: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public List<Annonce> searchAnnonces(String keyword) throws ServiceException {
        try {
            if (keyword == null || keyword.trim().isEmpty()) {
                return getAllAnnonces(); // Retourner toutes les annonces si pas de mot-clé
            }

            return annonceDAO.searchAnnonces(keyword);
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la recherche d'annonces: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public int countAnnonces() throws ServiceException {
        try {
            return annonceDAO.countAnnonces();
        } catch (Exception e) {
            throw new ServiceException("Erreur lors du comptage des annonces: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public Annonce getAnnonceById(int id) throws ServiceException {
        try {
            // Note: Vous devez ajouter cette méthode dans votre AnnonceDAO
            // Pour l'instant, je vais simuler la logique

            List<Annonce> annonces = getAllAnnonces();
            for (Annonce annonce : annonces) {
                if (annonce.getId() == id) {
                    return annonce;
                }
            }

            throw new ServiceException("Annonce non trouvée avec l'ID: " + id,
                ServiceException.ErrorType.NOT_FOUND);

        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la récupération de l'annonce: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    @Override
    public boolean deleteAnnonce(int id, int etudiantId) throws ServiceException {
        try {
            // Récupérer l'annonce
            Annonce annonce = getAnnonceById(id);

            // Vérifier les droits
            if (annonce.getEtudiant_id() != etudiantId) {
                throw new ServiceException("Vous n'avez pas les droits pour supprimer cette annonce",
                    ServiceException.ErrorType.UNAUTHORIZED);
            }

            // Supprimer l'annonce
            // Note: Vous devez ajouter cette méthode dans votre AnnonceDAO
            boolean success = deleteAnnonceFromDAO(id);

            if (!success) {
                throw new ServiceException("Erreur lors de la suppression de l'annonce",
                    ServiceException.ErrorType.DATABASE_ERROR);
            }

            return true;

        } catch (ServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la suppression de l'annonce: " + e.getMessage(),
                ServiceException.ErrorType.DATABASE_ERROR, e);
        }
    }

    // Méthode privée pour la validation
    private void validateAnnonce(Annonce annonce) throws ServiceException {
        if (annonce == null) {
            throw new ServiceException("L'annonce ne peut pas être nulle",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (annonce.getTitre() == null || annonce.getTitre().trim().isEmpty()) {
            throw new ServiceException("Le titre est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (annonce.getTitre().length() > 100) {
            throw new ServiceException("Le titre ne doit pas dépasser 100 caractères",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (annonce.getType_service() == null || annonce.getType_service().trim().isEmpty()) {
            throw new ServiceException("Le type de service est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (annonce.getDescription() == null || annonce.getDescription().trim().isEmpty()) {
            throw new ServiceException("La description est obligatoire",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (annonce.getDescription().length() > 1000) {
            throw new ServiceException("La description ne doit pas dépasser 1000 caractères",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (annonce.getPrix() < 0) {
            throw new ServiceException("Le prix ne peut pas être négatif",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }

        if (annonce.getEtudiant_id() <= 0) {
            throw new ServiceException("ID étudiant invalide",
                ServiceException.ErrorType.VALIDATION_ERROR);
        }
    }

    // Méthode temporaire (à implémenter dans AnnonceDAO)
    private boolean deleteAnnonceFromDAO(int id) {
        // Implémentation temporaire - à remplacer par votre logique DAO
        System.out.println("Suppression de l'annonce avec ID: " + id);
        return true;
    }
}
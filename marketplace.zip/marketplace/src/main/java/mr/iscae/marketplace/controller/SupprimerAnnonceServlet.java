package mr.iscae.marketplace.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import mr.iscae.marketplace.dao.AnnonceDAO;
import mr.iscae.marketplace.model.Annonce;
import mr.iscae.marketplace.model.Etudiant;

@WebServlet("/SupprimerAnnonceServlet")
public class SupprimerAnnonceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AnnonceDAO annonceDAO;

    @Override
    public void init() throws ServletException {
        annonceDAO = new AnnonceDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Vérifier si l'utilisateur est connecté
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("etudiant") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Etudiant etudiant = (Etudiant) session.getAttribute("etudiant");

        try {
            int annonceId = Integer.parseInt(request.getParameter("id"));

            // Vérifier que l'annonce existe et appartient à l'étudiant
            Annonce annonce = annonceDAO.getAnnonceById(annonceId);

            if (annonce == null) {
                session.setAttribute("errorMessage", "Annonce non trouvée.");
                response.sendRedirect("index.jsp");
                return;
            }

            if (annonce.getEtudiant_id() != etudiant.getId()) {
                session.setAttribute("errorMessage", "Vous n'avez pas les droits pour supprimer cette annonce.");
                response.sendRedirect("index.jsp");
                return;
            }

            // Supprimer l'annonce
            boolean success = annonceDAO.deleteAnnonce(annonceId, etudiant.getId());

            if (success) {
                session.setAttribute("successMessage", "Annonce supprimée avec succès !");
            } else {
                session.setAttribute("errorMessage", "Erreur lors de la suppression de l'annonce.");
            }

            response.sendRedirect("index.jsp");

        } catch (NumberFormatException e) {
            session.setAttribute("errorMessage", "ID d'annonce invalide.");
            response.sendRedirect("index.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMessage", "Erreur technique : " + e.getMessage());
            response.sendRedirect("index.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Rediriger vers la page d'accueil si accès direct en GET
        response.sendRedirect("index.jsp");
    }
}
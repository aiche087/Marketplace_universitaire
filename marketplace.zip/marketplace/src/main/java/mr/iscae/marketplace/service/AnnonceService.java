package mr.iscae.marketplace.service;

import java.util.List;

import mr.iscae.marketplace.model.Annonce;

public interface AnnonceService {

    /**
     * Ajouter une nouvelle annonce
     * @param annonce l'annonce à ajouter
     * @return l'annonce créée avec son ID
     * @throws ServiceException si une erreur survient
     */
    Annonce addAnnonce(Annonce annonce) throws ServiceException;

    /**
     * Récupérer toutes les annonces
     * @return liste des annonces
     * @throws ServiceException si une erreur survient
     */
    List<Annonce> getAllAnnonces() throws ServiceException;

    /**
     * Récupérer les annonces par type de service
     * @param service le type de service
     * @return liste des annonces du service spécifié
     * @throws ServiceException si une erreur survient
     */
    List<Annonce> getAnnoncesByService(String service) throws ServiceException;

    /**
     * Rechercher des annonces
     * @param keyword mot-clé de recherche
     * @return liste des annonces correspondantes
     * @throws ServiceException si une erreur survient
     */
    List<Annonce> searchAnnonces(String keyword) throws ServiceException;

    /**
     * Compter le nombre total d'annonces
     * @return nombre d'annonces
     * @throws ServiceException si une erreur survient
     */
    int countAnnonces() throws ServiceException;

    /**
     * Récupérer une annonce par son ID
     * @param id l'ID de l'annonce
     * @return l'annonce correspondante
     * @throws ServiceException si l'annonce n'existe pas ou si une erreur survient
     */
    Annonce getAnnonceById(int id) throws ServiceException;

    /**
     * Supprimer une annonce
     * @param id l'ID de l'annonce à supprimer
     * @param etudiantId l'ID de l'étudiant qui tente de supprimer
     * @return true si la suppression a réussi
     * @throws ServiceException si l'annonce n'existe pas ou si l'utilisateur n'a pas les droits
     */
    boolean deleteAnnonce(int id, int etudiantId) throws ServiceException;
}
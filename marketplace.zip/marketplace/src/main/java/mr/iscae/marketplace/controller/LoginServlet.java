package mr.iscae.marketplace.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import mr.iscae.marketplace.dao.EtudiantDAO;
import mr.iscae.marketplace.model.Etudiant;
import mr.iscae.marketplace.utils.PasswordUtil;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private EtudiantDAO etudiantDAO;

    @Override
    public void init() throws ServletException {
        etudiantDAO = new EtudiantDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validation des champs
        if (email == null || email.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {

            HttpSession session = request.getSession();
            session.setAttribute("errorMessage", "Veuillez remplir tous les champs");
            response.sendRedirect("login.jsp");
            return;
        }

        email = email.trim();
        password = password.trim();

        // 🔥 NOUVELLE LOGIQUE DE LOGIN
        Etudiant etudiant = etudiantDAO.findByEmailForLogin(email);

        if (etudiant != null) {

            String storedPassword = etudiant.getPassword();
            boolean passwordOk = false;

            // 🟠 Cas 1 : ancien mot de passe NON hashé
            if (storedPassword != null && !storedPassword.startsWith("$2a$")) {

                passwordOk = storedPassword.equals(password);

                // Migration automatique vers BCrypt
                if (passwordOk) {
                    String hashed = PasswordUtil.hash(password);
                    etudiantDAO.updatePassword(email, hashed);
                }

            }
            // 🟢 Cas 2 : mot de passe déjà hashé
            else if (storedPassword != null) {
                passwordOk = PasswordUtil.verify(password, storedPassword);
            }

            if (passwordOk) {
                HttpSession session = request.getSession();
                session.setAttribute("etudiant", etudiant);
                session.setAttribute("nom", etudiant.getNom());
                session.setAttribute("email", etudiant.getEmail());
                session.setAttribute("id", etudiant.getId());

                // CSRF + session
                session.setAttribute("csrfToken", java.util.UUID.randomUUID().toString());
                session.setAttribute("lastActivity", System.currentTimeMillis());
                session.setMaxInactiveInterval(30 * 60);

                session.setAttribute("successMessage",
                        "Connexion réussie ! Bienvenue " + etudiant.getNom());

                String redirectUrl = (String) session.getAttribute("redirectAfterLogin");
                if (redirectUrl != null) {
                    session.removeAttribute("redirectAfterLogin");
                    response.sendRedirect(redirectUrl);
                } else {
                    response.sendRedirect("index.jsp");
                }
                return;
            }
        }

        // ❌ Échec de connexion
        HttpSession session = request.getSession();
        session.setAttribute("errorMessage", "Email ou mot de passe incorrect");
        response.sendRedirect("login.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session != null && session.getAttribute("etudiant") != null) {
            response.sendRedirect("index.jsp");
            return;
        }

        request.getRequestDispatcher("login.jsp").forward(request, response);
    }
}

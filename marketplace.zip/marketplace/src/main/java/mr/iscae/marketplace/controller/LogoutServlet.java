package mr.iscae.marketplace.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processLogout(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processLogout(request, response);
    }

    private void processLogout(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        // 1. Récupérer le nom avant de détruire la session
        HttpSession session = request.getSession(false);
        String nomUtilisateur = null;
        String successMessage = null;

        if (session != null) {
            nomUtilisateur = (String) session.getAttribute("nom");

            // 2. PERSONNALISER le message AVANT d'invalider
            if (nomUtilisateur != null && !nomUtilisateur.trim().isEmpty()) {
                successMessage = "Au revoir " + nomUtilisateur + " ! Vous avez été déconnecté avec succès.";
            } else {
                successMessage = "Vous avez été déconnecté avec succès.";
            }

            // 3. Invalider la session
            session.invalidate();
        }

        // 4. FORCER la suppression du cookie JSESSIONID côté client
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("JSESSIONID")) {
                    cookie.setValue("");
                    cookie.setMaxAge(0); // Expire immédiatement
                    cookie.setPath(request.getContextPath().isEmpty() ? "/" : request.getContextPath());
                    response.addCookie(cookie);
                    break;
                }
            }
        }

        // 5. Ajouter des en-têtes pour empêcher la mise en cache
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Expires", "0");

        // 6. Rediriger AVEC le message dans l'URL
        if (successMessage != null) {
            // Encoder le message pour l'URL
            String encodedMessage = java.net.URLEncoder.encode(successMessage, "UTF-8");
            response.sendRedirect("login.jsp?success=" + encodedMessage);
        } else {
            response.sendRedirect("login.jsp");
        }
    }
}
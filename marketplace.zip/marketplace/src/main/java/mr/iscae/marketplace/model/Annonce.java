package mr.iscae.marketplace.model;

import java.io.Serializable;
import java.util.Date;

public class Annonce implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String titre;
    private Date date;
    private String type_service;
    private String description;
    private double prix;
    private String image;
    private int etudiant_id;

    public Annonce() {
        this.date = new Date();
    }

    public Annonce(String titre, String type_service, String description, double prix, String image, int etudiant_id) {
        this.titre = titre;
        this.type_service = type_service;
        this.description = description;
        this.prix = prix;
        this.image = image;
        this.etudiant_id = etudiant_id;
        this.date = new Date();
    }

    // Getters et setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
    public String getType_service() { return type_service; }
    public void setType_service(String type_service) { this.type_service = type_service; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public double getPrix() { return prix; }
    public void setPrix(double prix) { this.prix = prix; }
    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }
    public int getEtudiant_id() { return etudiant_id; }
    public void setEtudiant_id(int etudiant_id) { this.etudiant_id = etudiant_id; }

    @Override
    public String toString() {
        return "Annonce [id=" + id + ", titre=" + titre + ", date=" + date + ", type_service=" + type_service
                + ", description=" + description + ", prix=" + prix + ", image=" + image + ", etudiant_id=" + etudiant_id
                + "]";
    }
}

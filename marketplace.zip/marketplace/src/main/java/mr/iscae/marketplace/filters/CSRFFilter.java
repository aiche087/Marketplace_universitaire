package mr.iscae.marketplace.filters;

import java.io.IOException;
import java.util.UUID;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter({"/AjouterAnnonceServlet", "/ModifierAnnonceServlet",
           "/SupprimerAnnonceServlet"})
public class CSRFFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        // Ne s'applique qu'aux méthodes POST
        if ("POST".equalsIgnoreCase(req.getMethod())) {
            HttpSession session = req.getSession(false);

            // Récupérer le token de la session et de la requête
            String sessionToken = session != null ? (String) session.getAttribute("csrfToken") : null;
            String requestToken = req.getParameter("csrfToken");

            // Vérifier la correspondance
            if (sessionToken == null || !sessionToken.equals(requestToken)) {
                res.sendError(HttpServletResponse.SC_FORBIDDEN, "Token CSRF invalide");
                return;
            }

            // Régénérer le token après utilisation
            if (session != null) {
                session.setAttribute("csrfToken", UUID.randomUUID().toString());
            }
        }

        chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialisation
    }

    @Override
    public void destroy() {
        // Nettoyage
    }
}
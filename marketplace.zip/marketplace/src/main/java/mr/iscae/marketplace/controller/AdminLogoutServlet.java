package mr.iscae.marketplace.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AdminLogoutServlet")
public class AdminLogoutServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session != null) {
            // Récupérer l'email avant de détruire la session (pour le message)
            String adminEmail = (String) session.getAttribute("adminEmail");
            
            // Détruire la session
            session.invalidate();
            
            System.out.println("🔴 Admin déconnecté: " + adminEmail);
        }

        // Créer une nouvelle session pour le message
        HttpSession newSession = request.getSession();
        newSession.setAttribute("successMessage", "Vous avez été déconnecté avec succès");

        // Rediriger vers la page de connexion admin
        response.sendRedirect(request.getContextPath() + "/adminLogin.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
